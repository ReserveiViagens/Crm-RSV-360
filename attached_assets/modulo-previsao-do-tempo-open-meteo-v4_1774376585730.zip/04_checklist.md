# 04_checklist.md
## Projeto: Módulo de Previsão do Tempo com Open-Meteo
## Versão: 4.0
## Data: 2026-03-24

---

# 1. Checklist de implementação

## 1.1 Utils
- [ ] criar `server/utils/weather-code-map.js`
- [ ] criar `server/utils/weather-normalizer.js`
- [ ] criar `server/utils/weather-validators.js`
- [ ] mapear weather code para label legível
- [ ] normalizar payload externo para contrato interno
- [ ] validar cidade, país e coordenadas

## 1.2 Cache
- [ ] criar `server/lib/weather-cache.js`
- [ ] implementar TTL de 60 min
- [ ] implementar stale de 6 horas
- [ ] criar chaves por cidade
- [ ] criar chaves por coordenadas

## 1.3 Provider
- [ ] criar `server/providers/open-meteo-provider.js`
- [ ] implementar geocoding
- [ ] implementar forecast
- [ ] adicionar timeout externo
- [ ] tratar respostas inválidas

## 1.4 Service
- [ ] criar `server/services/weather-service.js`
- [ ] implementar `getWeatherByCity`
- [ ] implementar `getWeatherByCoords`
- [ ] integrar cache
- [ ] integrar normalizador
- [ ] integrar fallback stale

## 1.5 Routes
- [ ] criar `server/routes/weather-routes.js`
- [ ] expor `GET /api/weather`
- [ ] expor `GET /api/weather/by-coords`
- [ ] expor `POST /internal/weather/warmup` se necessário
- [ ] validar entradas
- [ ] retornar status HTTP corretos
- [ ] padronizar resposta de erro

## 1.6 Registro no app
- [ ] importar `weather-routes`
- [ ] registrar no `server/app.js`

## 1.7 Frontend
- [ ] criar `client/src/services/weather-api.js`
- [ ] criar `client/src/hooks/useWeather.js`
- [ ] criar `client/src/components/WeatherCard.jsx`
- [ ] criar `WeatherForecastList.jsx` se necessário
- [ ] renderizar loading
- [ ] renderizar erro
- [ ] renderizar estado de sucesso

---

# 2. Checklist funcional

## 2.1 Busca por cidade
- [ ] buscar clima por cidade
- [ ] aceitar `country` opcional
- [ ] responder com payload normalizado

## 2.2 Busca por coordenadas
- [ ] buscar clima por lat/lon
- [ ] validar ranges numéricos
- [ ] responder com payload normalizado

## 2.3 Cache
- [ ] retornar HIT corretamente
- [ ] retornar MISS corretamente
- [ ] retornar STALE quando a API falhar

## 2.4 Erros
- [ ] tratar city ausente
- [ ] tratar coordenadas inválidas
- [ ] tratar cidade não encontrada
- [ ] tratar timeout externo
- [ ] tratar indisponibilidade do provider

---

# 3. Checklist de UI

- [ ] mostrar nome do local
- [ ] mostrar temperatura atual
- [ ] mostrar label do clima
- [ ] mostrar máxima/mínima
- [ ] mostrar chance de chuva
- [ ] mostrar vento
- [ ] mostrar 3 dias de previsão
- [ ] esconder dados técnicos em página pública

---

# 4. Checklist de qualidade

- [ ] frontend não consome Open-Meteo diretamente
- [ ] payload bruto não vaza para a UI
- [ ] service está separado da route
- [ ] provider está separado do service
- [ ] cache está isolado
- [ ] normalizador está isolado
- [ ] validadores estão isolados
- [ ] nomes de arquivos estão claros
- [ ] funções têm responsabilidade única

---

# 5. Checklist de observabilidade

- [ ] logar cidade consultada
- [ ] logar país consultado
- [ ] logar lat/lon quando aplicável
- [ ] logar cache mode
- [ ] logar tempo de resposta externo
- [ ] logar erro externo com contexto

---

# 6. Checklist de testes mínimos

## Backend
- [ ] cidade válida
- [ ] cidade inválida
- [ ] city ausente
- [ ] country ausente
- [ ] coordenadas válidas
- [ ] coordenadas inválidas
- [ ] cache HIT
- [ ] cache MISS
- [ ] cache STALE
- [ ] falha externa sem cache

## Frontend
- [ ] loading inicial
- [ ] erro da API
- [ ] renderização com dados válidos
- [ ] troca de cidade
- [ ] dados parciais nulos

---

# 7. Critérios de aceite finais

A entrega só pode ser considerada concluída quando todos forem verdadeiros:

- [ ] o módulo funciona por cidade
- [ ] o módulo funciona por coordenadas
- [ ] o cache funciona
- [ ] o fallback stale funciona
- [ ] o contrato JSON está estável
- [ ] a UI está desacoplada do provider
- [ ] a arquitetura está modularizada
- [ ] a base permite evolução futura

---
