# 03_plano-de-arquivos.md
## Projeto: Módulo de Previsão do Tempo com Open-Meteo
## Versão: 4.0
## Data: 2026-03-24

---

# 1. Estrutura alvo

```text
server/
  app.js
  routes/
    weather-routes.js
  services/
    weather-service.js
  providers/
    open-meteo-provider.js
  lib/
    weather-cache.js
  utils/
    weather-code-map.js
    weather-normalizer.js
    weather-validators.js

client/
  src/
    components/
      WeatherCard.jsx
      WeatherForecastList.jsx
    hooks/
      useWeather.js
    services/
      weather-api.js
    types/
      weather.ts
```

---

# 2. Plano por arquivo

## 2.1 `server/utils/weather-code-map.js`
### Responsabilidade
Mapear `weather_code` para rótulo amigável.

### Interface esperada
```js
const WEATHER_CODE_MAP = {};
function weatherCodeToLabel(code) {}
module.exports = { WEATHER_CODE_MAP, weatherCodeToLabel };
```

---

## 2.2 `server/utils/weather-normalizer.js`
### Responsabilidade
Converter payload bruto do provider no contrato interno do sistema.

### Interface esperada
```js
function normalizeWeatherPayload(location, raw) {}
module.exports = { normalizeWeatherPayload };
```

---

## 2.3 `server/utils/weather-validators.js`
### Responsabilidade
Validar cidade, país e coordenadas.

### Interface esperada
```js
function validateCityInput(city) {}
function validateCountryInput(country) {}
function validateCoordinates(lat, lon) {}

module.exports = {
  validateCityInput,
  validateCountryInput,
  validateCoordinates
};
```

---

## 2.4 `server/lib/weather-cache.js`
### Responsabilidade
Implementar cache em memória com TTL e stale window.

### Interface esperada
```js
class WeatherCache {
  get(key) {}
  set(key, value) {}
  isFresh(entry) {}
  isStaleAllowed(entry) {}
  buildCityKey(city, country) {}
  buildCoordsKey(lat, lon) {}
}

module.exports = { WeatherCache };
```

---

## 2.5 `server/providers/open-meteo-provider.js`
### Responsabilidade
Encapsular toda comunicação com a Open-Meteo.

### Interface esperada
```js
async function geocodeCity(city, country = "BR") {}
async function fetchForecast(lat, lon, timezone = "America/Sao_Paulo") {}

module.exports = {
  geocodeCity,
  fetchForecast
};
```

---

## 2.6 `server/services/weather-service.js`
### Responsabilidade
Orquestrar cache + provider + normalização + fallback.

### Interface esperada
```js
async function getWeatherByCity(city, country = "BR") {}
async function getWeatherByCoords(lat, lon) {}

module.exports = {
  getWeatherByCity,
  getWeatherByCoords
};
```

---

## 2.7 `server/routes/weather-routes.js`
### Responsabilidade
Definir rotas HTTP e integrar com o serviço.

### Interface esperada
```js
router.get("/api/weather", async (req, res) => {});
router.get("/api/weather/by-coords", async (req, res) => {});
router.post("/internal/weather/warmup", async (req, res) => {});
```

---

## 2.8 `server/app.js`
### Responsabilidade
Registrar as rotas do módulo.

### Alteração esperada
```diff
+ const weatherRoutes = require("./routes/weather-routes");
+ app.use(weatherRoutes);
```

---

## 2.9 `client/src/services/weather-api.js`
### Responsabilidade
Consumir apenas a API interna.

### Interface esperada
```js
export async function fetchWeatherByCity(city, country = "BR") {}
export async function fetchWeatherByCoords(lat, lon) {}
```

---

## 2.10 `client/src/hooks/useWeather.js`
### Responsabilidade
Encapsular loading, erro e sucesso.

### Interface esperada
```js
export function useWeather(params) {}
```

---

## 2.11 `client/src/components/WeatherCard.jsx`
### Responsabilidade
Renderizar o card principal de clima.

### Interface esperada
```jsx
export function WeatherCard({ city, country = "BR" }) {
  return null;
}
```

---

## 2.12 `client/src/components/WeatherForecastList.jsx`
### Responsabilidade
Renderizar a lista resumida da previsão.

### Observação
Opcional se o WeatherCard já renderizar os dias internamente.

---

## 2.13 `client/src/types/weather.ts`
### Responsabilidade
Definir tipos do contrato interno quando o frontend usar TypeScript.

---

# 3. Ordem de criação dos arquivos

1. `server/utils/weather-code-map.js`
2. `server/utils/weather-normalizer.js`
3. `server/utils/weather-validators.js`
4. `server/lib/weather-cache.js`
5. `server/providers/open-meteo-provider.js`
6. `server/services/weather-service.js`
7. `server/routes/weather-routes.js`
8. atualização de `server/app.js`
9. `client/src/services/weather-api.js`
10. `client/src/hooks/useWeather.js`
11. `client/src/components/WeatherCard.jsx`
12. `client/src/components/WeatherForecastList.jsx` se necessário
13. `client/src/types/weather.ts` se TypeScript

---

# 4. Diff lógico esperado

```diff
+ server/utils/weather-code-map.js
+ server/utils/weather-normalizer.js
+ server/utils/weather-validators.js
+ server/lib/weather-cache.js
+ server/providers/open-meteo-provider.js
+ server/services/weather-service.js
+ server/routes/weather-routes.js
* server/app.js

+ client/src/services/weather-api.js
+ client/src/hooks/useWeather.js
+ client/src/components/WeatherCard.jsx
+ client/src/components/WeatherForecastList.jsx
+ client/src/types/weather.ts
```

---

# 5. Regras de responsabilidade

- rota não faz normalização pesada
- provider não faz renderização
- UI não conhece URL da Open-Meteo
- service coordena fluxo
- cache não conhece detalhes de React
- normalizer não conhece Express

---

# 6. Anti-patterns por arquivo

## Rotas
- lógica de negócio extensa
- chamadas externas diretas sem service

## Service
- manipulação de DOM
- dependência de componente

## Provider
- acoplamento com resposta visual

## UI
- fetch para Open-Meteo
- parse do payload externo

---
