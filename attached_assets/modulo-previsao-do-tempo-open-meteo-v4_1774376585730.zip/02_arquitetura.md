# 02_arquitetura.md
## Projeto: Módulo de Previsão do Tempo com Open-Meteo
## Versão: 4.0
## Data: 2026-03-24

---

# 1. Visão arquitetural

A arquitetura do módulo deve seguir o modelo **backend-first**.

## Fluxo obrigatório

```text
[React UI]
  -> [weather-api.js]
  -> [useWeather.js]
  -> [GET /api/weather ou /api/weather/by-coords]

[Express Route]
  -> [weather-service.js]
  -> [weather-cache.js]
  -> [open-meteo-provider.js]
  -> [weather-normalizer.js]
  -> [weather-code-map.js]
```

---

# 2. Camadas e responsabilidades

## 2.1 Frontend UI
Responsável por:
- exibir clima
- mostrar loading
- mostrar erro
- exibir previsão resumida

## 2.2 Frontend service/hook
Responsável por:
- chamar a API interna
- encapsular fetch
- controlar estado do carregamento

## 2.3 Route
Responsável por:
- validar entrada
- chamar o serviço
- devolver JSON
- controlar status HTTP
- aplicar cabeçalhos de cache

## 2.4 Service
Responsável por:
- orquestrar fluxo principal
- consultar cache
- chamar provider
- aplicar normalização
- controlar fallback stale

## 2.5 Provider
Responsável por:
- consultar geocoding
- consultar forecast
- isolar integração externa

## 2.6 Cache
Responsável por:
- armazenar resultados
- controlar TTL
- permitir stale fallback
- construir chaves estáveis

## 2.7 Utils
Responsáveis por:
- validar parâmetros
- mapear códigos climáticos
- normalizar payload externo

---

# 3. Endpoints obrigatórios

## 3.1 Por cidade
```http
GET /api/weather?city=Caldas%20Novas&country=BR
```

## 3.2 Por coordenadas
```http
GET /api/weather/by-coords?lat=-17.7445&lon=-48.6250
```

## 3.3 Warmup interno
```http
POST /internal/weather/warmup
```

---

# 4. Contrato interno do backend

Toda resposta deve seguir estrutura estável e independente do provider.

```json
{
  "location": {
    "name": "Caldas Novas",
    "state": "Goiás",
    "country": "Brazil",
    "latitude": -17.7445,
    "longitude": -48.6250
  },
  "current": {
    "temperature": 28.4,
    "windSpeed": 12.1,
    "weatherCode": 1,
    "label": "Poucas nuvens"
  },
  "today": {
    "min": 21.2,
    "max": 30.8,
    "rainProbability": 35,
    "precipitation": 1.4
  },
  "daily": [
    {
      "date": "2026-03-24",
      "min": 21.2,
      "max": 30.8,
      "weatherCode": 1,
      "rainProbability": 35,
      "precipitation": 1.4
    }
  ],
  "updatedAt": "2026-03-24T13:00:00Z",
  "cacheTtlMinutes": 60
}
```

Campos internos opcionais:
- `_cache`
- `_provider`
- `_sourceLatencyMs`

---

# 5. Política de cache

## TTL padrão
- 60 minutos

## Janela stale
- 6 horas

## Chaves
### Cidade
```text
weather:city:{city}:{country}
```

### Coordenadas
```text
weather:coords:{lat}:{lon}
```

## Comportamento
- HIT: responde imediatamente
- MISS: consulta provider e salva
- STALE: usa cache expirado recente quando a API falha
- ERROR: falha sem cache disponível

---

# 6. Timeout e resiliência

## Timeout externo
- entre 4 e 6 segundos

## Erros que devem ser tratados
- cidade não encontrada
- latitude inválida
- longitude inválida
- timeout externo
- indisponibilidade do provider
- payload inesperado
- parâmetro obrigatório ausente

## Formato padrão de erro
```json
{
  "error": true,
  "message": "Parâmetro city é obrigatório"
}
```

---

# 7. Dados do provider que devem ser solicitados

## Current
- temperature_2m
- weather_code
- wind_speed_10m

## Daily
- weather_code
- temperature_2m_max
- temperature_2m_min
- precipitation_sum
- precipitation_probability_max

## Hourly
- temperature_2m
- precipitation_probability
- precipitation

---

# 8. Regras de validação

## Cidade
- string não vazia
- trim obrigatório
- tamanho mínimo 2

## País
- default BR
- idealmente ISO 2 letras

## Latitude
- -90 a 90

## Longitude
- -180 a 180

---

# 9. Regras de UI

## Página pública
Mostrar apenas:
- temperatura atual
- condição
- máxima/mínima
- chuva
- 3 dias

## Página detalhada
Pode exibir até 7 dias

## Admin
Pode exibir:
- cache mode
- payload expandido
- updatedAt
- dados técnicos

---

# 10. Princípios finais

- frontend nunca conversa com provider externo
- backend sempre normaliza
- cache é obrigatório
- provider deve ser isolado
- service deve orquestrar
- route deve ser fina
- UI deve ser simples e amigável

---
