# 01_contexto.md
## Projeto: Módulo de Previsão do Tempo com Open-Meteo
## Versão: 4.0
## Data: 2026-03-24

---

# 1. Objetivo

Este documento define o **contexto funcional e estratégico** do módulo de previsão do tempo para o sistema.

O objetivo é adicionar uma camada de clima útil para páginas de:

- destino
- hotel
- parque aquático
- checkout
- painel administrativo

A implementação deve ser:

- barata
- robusta
- desacoplada
- simples de manter
- pronta para crescer depois

---

# 2. Problema que estamos resolvendo

O sistema precisa mostrar informações climáticas relevantes para o usuário sem:

- depender diretamente do provedor no frontend
- elevar custo de operação
- gerar excesso de chamadas externas
- acoplar UI ao payload bruto da API

Além disso, o clima precisa ser aproveitado de forma prática em páginas que influenciam decisão de compra.

---

# 3. Resultado esperado

Ao final da implementação, o sistema deve conseguir exibir:

- temperatura atual
- condição climática atual
- vento atual
- máxima e mínima do dia
- chance de chuva
- precipitação do dia
- previsão curta de 3 dias
- possibilidade de estender para 7 dias

---

# 4. Casos de uso prioritários

## 4.1 Página do destino
Exemplos:
- Caldas Novas
- Rio Quente
- Olímpia

Mostrar:
- clima atual
- máxima/mínima
- chance de chuva
- previsão curta

## 4.2 Página do hotel
Mostrar:
- clima do local
- resumo do dia
- contexto para a estadia

## 4.3 Página do parque aquático
Mostrar:
- temperatura atual
- chance de chuva
- máxima do dia
- previsão curta

## 4.4 Checkout / confirmação
Mostrar:
- previsão resumida
- mensagem orientativa simples para viagem

## 4.5 Painel administrativo
Mostrar:
- dados completos
- horário da última atualização
- status do cache
- dados úteis para suporte e validação

---

# 5. Decisão de provedor

## Provedor principal
**Open-Meteo**

## Motivos da escolha
- excelente custo-benefício
- entrada simples
- geocoding disponível
- forecast suficiente para o caso de uso
- fácil uso com cache server-side
- boa base para MVP e crescimento

---

# 6. Princípio central da solução

O frontend **não deve consumir Open-Meteo diretamente**.

Toda consulta deve seguir este fluxo:

```text
Frontend -> API interna -> Serviço de clima -> Cache -> Open-Meteo
```

Isso garante:

- menor acoplamento
- mais controle
- possibilidade de cache
- troca futura de provider
- melhor controle de falhas

---

# 7. Restrições inegociáveis

- não consumir Open-Meteo no React diretamente
- não repassar payload bruto do provedor
- não implementar sem cache
- não espalhar lógica meteorológica em vários arquivos sem critério
- não deixar a rota fazer tudo
- não ignorar timeout e fallback
- não expor erros internos ao usuário final

---

# 8. Escopo funcional da V1

A primeira versão deve cobrir:

- busca por cidade
- busca por coordenadas
- endpoint interno
- cache em memória
- fallback stale
- normalização do payload
- componente frontend simples
- estados de loading, erro e sucesso

---

# 9. Escopo fora da V1, mas previsto

Estas evoluções não precisam entrar na primeira entrega, mas a arquitetura deve permitir:

- Redis
- warmup automático
- múltiplos provedores
- previsão associada a datas de reserva
- alertas operacionais
- recomendações automáticas por clima

---

# 10. Resultado arquitetural desejado

Ao final, o projeto deve estar organizado em camadas claras:

- rota
- serviço
- provider
- cache
- normalizador
- validador
- componente de UI
- hook ou service do frontend

---

# 11. Resumo executivo

A melhor solução para este caso é:

**Open-Meteo + backend próprio + cache + payload normalizado + componente frontend desacoplado**

Esse modelo entrega:

- baixo custo
- velocidade de implementação
- estabilidade
- flexibilidade futura
- base sólida para produção

---
